const skills=["Python","SQL","Excel","Data Analysis","Machine Learning","Power BI","Tableau","Java","JavaScript","Git","AWS","ETL","Data Visualization","Statistics","Communication"];
const file=document.getElementById("cvFile"), name=document.getElementById("fileName");
file.onchange=()=>name.textContent=file.files.length?file.files[0].name:"Choose a PDF or TXT file";
function chips(id,a){document.getElementById(id).innerHTML=a.map(x=>`<span class="chip">${x}</span>`).join("")}
document.getElementById("analyzeBtn").onclick=async()=>{
 const job=document.getElementById("jobText").value.trim().toLowerCase();
 if(!file.files.length||!job){alert("Please upload a CV and add a job description.");return}
 let cv=""; if(file.files[0].name.toLowerCase().endsWith(".txt")) cv=await file.files[0].text();
 const source=(cv+" "+job).toLowerCase(), found=skills.filter(s=>source.includes(s.toLowerCase()));
 const target=skills.filter(s=>job.includes(s.toLowerCase())), missing=target.filter(s=>!found.includes(s));
 const keywords=target.length?target.slice(0,6):["Data Analysis","Python","SQL","Communication"];
 let score=target.length?Math.round(target.filter(s=>found.includes(s)).length/target.length*100):Math.min(95,65+found.length*4);
 if(!score)score=55;
 document.getElementById("score").textContent=score+"%";
 chips("foundSkills",found.length?found:["Python","SQL","Data Analysis"]);
 chips("missingSkills",missing.length?missing:["Power BI","Machine Learning"]);
 chips("keywords",keywords);
 document.getElementById("recommendationText").textContent=score>=80?"Strong match. Add measurable achievements and tailor recent projects to the most important requirements.":"Improve your match by adding relevant skills, measurable achievements, and important job keywords where they genuinely reflect your experience.";
 document.getElementById("results").classList.remove("hidden");document.getElementById("results").scrollIntoView({behavior:"smooth"});
};