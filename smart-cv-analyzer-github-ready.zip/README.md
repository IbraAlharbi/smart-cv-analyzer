# Smart CV Analyzer

AI-powered CV and job matching capstone project.

## Features
- CV upload
- Job-description input
- Match score
- Skills found
- Skill gaps
- Recommended keywords
- AI-style improvement recommendation
- Responsive GitHub Pages interface

## Publish on GitHub Pages
1. Create a **Public** repository named `smart-cv-analyzer`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md`.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, branch `main`, folder `/ (root)`.
5. Save.

The published address will be:
`https://YOUR-USERNAME.github.io/smart-cv-analyzer/`

## Submission details
**Project name:** Smart CV Analyzer

**Description:** An AI-powered web application that analyzes a CV against a target job description, identifies relevant skills and gaps, and provides actionable recommendations to improve job matching.

**Repository:** `https://github.com/YOUR-USERNAME/smart-cv-analyzer`
