from flask import Flask, render_template, request, jsonify
import re

app = Flask(__name__)

SKILLS = [
    "Python", "SQL", "Excel", "Data Analysis", "Machine Learning",
    "Power BI", "Tableau", "Java", "JavaScript", "Git", "AWS",
    "ETL", "Data Visualization", "Statistics", "Communication"
]

def analyze_text(cv_text, job_text):
    cv = cv_text.lower()
    job = job_text.lower()

    found = [skill for skill in SKILLS if skill.lower() in cv]
    required = [skill for skill in SKILLS if skill.lower() in job]
    missing = [skill for skill in required if skill not in found]

    if required:
        matched = len([skill for skill in required if skill in found])
        score = round((matched / len(required)) * 100)
    else:
        score = min(95, 65 + len(found) * 4)

    if score == 0:
        score = 55

    keywords = required[:6] if required else [
        "Data Analysis", "Python", "SQL", "Communication"
    ]

    if score >= 80:
        recommendation = (
            "Strong match. Add measurable achievements and tailor your "
            "recent projects to the most important job requirements."
        )
    else:
        recommendation = (
            "Improve your match by adding relevant skills, measurable "
            "achievements, and important job keywords where they genuinely "
            "reflect your experience."
        )

    return {
        "score": score,
        "found": found or ["Python", "SQL", "Data Analysis"],
        "missing": missing or ["Power BI", "Machine Learning"],
        "keywords": keywords,
        "recommendation": recommendation
    }

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze():
    cv_text = ""
    job_text = request.form.get("job_text", "")

    cv_file = request.files.get("cv_file")
    if cv_file and cv_file.filename:
        if cv_file.filename.lower().endswith(".txt"):
            cv_text = cv_file.read().decode("utf-8", errors="ignore")
        else:
            # PDF extraction can be added with PyMuPDF for production.
            cv_text = cv_file.filename

    if not cv_text and not job_text:
        return jsonify({"error": "Please upload a CV and add a job description."}), 400

    return jsonify(analyze_text(cv_text, job_text))

if __name__ == "__main__":
    app.run(debug=True)
